// EXPERIMENT ONLY: fixed synthetic sources; not a general data-classification system.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { tool } from '/Users/subirmansukhani/.config/opencode/node_modules/@opencode-ai/plugin/dist/tool.js';

const base = async ({ directory }) => {
  const marker = path.join(directory, '.pii-experiment.json');
  if (!fs.existsSync(marker)) return {};
  const config = JSON.parse(fs.readFileSync(marker, 'utf8'));
  if (!config.receipts) return {};
  const events = path.join(directory, 'receipt-events.jsonl');
  const record = event => fs.appendFileSync(events, JSON.stringify(event) + '\n');
  return {
    tool: {
      data_values: tool({
        description: 'Explicitly select values needed for the task from a synthetic source or result file. This sends the selected values through the LLM Gateway. Use local Python for calculations first. Not needed to show a table to the user.',
        args: { source: tool.schema.string(), columns: tool.schema.array(tool.schema.string()), reason: tool.schema.string() },
        async execute(args, ctx) {
          const source = path.resolve(directory, args.source);
          if (!source.startsWith(directory + path.sep) || !(/\.(csv|table\.json)$/.test(source))) return 'Select a CSV or table result inside this workspace.';
          const py = `import csv,json,sys\np=sys.argv[1]; cols=json.loads(sys.argv[2])\nif p.endswith('.csv'):\n rows=list(csv.DictReader(open(p)))\nelse:\n t=json.load(open(p)); rows=[dict(zip(t['columns'],r)) for r in t['rows']]\nselected=[{k:r[k] for k in cols} for r in rows]\nprint(json.dumps({'columns':cols,'rows':selected,'rows_total':len(rows),'rows_processed':len(selected),'complete':True}))`;
          const run = spawnSync(config.python, ['-c', py, source, JSON.stringify(args.columns)], {encoding:'utf8'});
          if (run.status !== 0) return 'Selection failed: check the source and column names. No values released.';
          record({type:'selection',session:ctx.sessionID,source:args.source,columns:args.columns,reason:args.reason,bytes:run.stdout.length});
          return run.stdout;
        }
      })
    },
    'experimental.chat.messages.transform': async (_, output) => {
      for (const message of output.messages) for (const part of message.parts || []) {
        if (part.type !== 'tool' || !part.state) continue;
        const state = part.state;
        const input = JSON.stringify(state.input || {});
        const dataRead = part.tool === 'read' && /sales\.csv|complaints\.csv|\.table\.json/.test(input);
        const suppress = dataRead || ['bash','task'].includes(part.tool);
        if (!suppress || !['completed','error'].includes(state.status)) continue;
        const original = state.status === 'error' ? state.error : state.output;
        const receipt = JSON.stringify({kind:'local_execution_receipt',tool:part.tool,status:state.status,
          note:'Full tool output remains local. Inspect source structure below; run local code to calculate and write artifacts. Use data_values only for selected values needed in the answer.',
          sources:config.sources,artifacts:fs.existsSync(path.join(directory,'examples/probe')) ? fs.readdirSync(path.join(directory,'examples/probe')) : [],
          exit:state.metadata?.exit ?? null});
        record({type:'transform',session:part.sessionID,tool:part.tool,call:part.callID,status:state.status,original_bytes:String(original||'').length,receipt_bytes:receipt.length});
        if (state.status === 'error') state.error=receipt; else state.output=receipt;
        if (state.metadata?.interrupted && typeof state.metadata.output === 'string') state.metadata={...state.metadata,output:receipt};
        state.attachments=[];
      }
    }
  };
};

export default async input => {
 const hooks=await base(input);
 if (!hooks.tool) return hooks;
 const config=JSON.parse(fs.readFileSync(path.join(input.directory,'.pii-experiment.json'),'utf8'));
 const select=hooks.tool.data_values.execute;
 hooks.tool.analyze_data=tool({
  description:'Compute locally and return only the selected result values in one operation. Write table artifacts in Python. stdout and errors stay in local files. Prefer this to bash followed by data_values for numerical tasks.',
  args:{code:tool.schema.string(),result_file:tool.schema.string(),columns:tool.schema.array(tool.schema.string()),reason:tool.schema.string()},
  async execute(args,ctx){
   const result=spawnSync(config.python,['-c',args.code],{cwd:input.directory,encoding:'utf8',timeout:30000});
   fs.writeFileSync(path.join(input.directory,'analysis-output.log'),(result.stdout||'')+(result.stderr||''));
   if(result.status!==0)return JSON.stringify({status:'error',exit:result.status,note:'Local analysis failed; full diagnostic is in analysis-output.log. No selected values released.'});
   return await select({source:args.result_file,columns:args.columns,reason:args.reason},ctx);
  }
 });
 return hooks;
};
