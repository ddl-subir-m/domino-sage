"""Synthetic batched value-processing proof; not an agent or semantic-quality benchmark."""
from pathlib import Path
import collections, concurrent.futures, json, sys, time, uuid
from dotenv import dotenv_values
sys.path.insert(0,str(Path.cwd()/'backend'))
from sage.gateway.client import OpenAICompatibleClient,CostLabels
root=Path('/tmp/sage-pii-prototype/coverage');root.mkdir(exist_ok=True)
v=dotenv_values('/Users/subirmansukhani/Desktop/domino-sage/backend/.env')
client=OpenAICompatibleClient(v['GATEWAY_BASE_URL'],lambda:v['GATEWAY_API_KEY'],domino_tags=True,read_timeout_s=65)
themes=['delivery','damage','billing'];phrases=['My order arrived a week late.','The item arrived with a cracked screen.','I was charged twice for the same purchase.']
records=[{'id':f'C{i:03}','text':phrases[i%3]} for i in range(60)]
expected={r['id']:themes[i%3] for i,r in enumerate(records)};runid=uuid.uuid4().hex
def batch(model,number):
 selected=records[number*20:(number+1)*20]
 prompt='Classify every supplied complaint as delivery, damage or billing. Return ONLY a JSON array of objects with exactly id and category. Include every input id exactly once. No introduction. Synthetic experiment '+runid+'\n'+json.dumps(selected)
 body={'model':model,'stream':True,'max_tokens':2400,'messages':[{'role':'user','content':prompt}]}
 start=time.monotonic();data=b'';error=None
 try:
  for chunk in client.route(body,CostLabels('ask','ask',component='probe',project_name='synthetic-pii-coverage')):data+=chunk
 except Exception as e:error=type(e).__name__
 content='';finish=[]
 for line in data.splitlines():
  if not line.startswith(b'data:') or line[5:].strip()==b'[DONE]':continue
  try:event=json.loads(line[5:])
  except ValueError:continue
  if event.get('error'):error='error_frame'
  for choice in event.get('choices',[]):
   content+=(choice.get('delta') or {}).get('content') or ''
   if choice.get('finish_reason'):finish.append(choice['finish_reason'])
 try:parsed=json.loads(content.strip().removeprefix('```json').removeprefix('```').removesuffix('```').strip())
 except ValueError:parsed=[];error=error or 'invalid_json'
 if not isinstance(parsed,list):parsed=[];error=error or 'invalid_shape'
 ids=[r.get('id') for r in parsed if isinstance(r,dict)]
 coverage=collections.Counter(ids)==collections.Counter(r['id'] for r in selected)
 correct=coverage and all(r.get('category')==expected[r['id']] for r in parsed)
 return {'model':model,'batch':number,'input_ids':[r['id'] for r in selected],'elapsed_s':time.monotonic()-start,'error':error,'finish':finish,'coverage_exact':coverage,'categories_correct':correct,'output':parsed,'answer':content}
results=[]
try:
 for model in ['sonnet','domino/gemini-3.7-flash','Gemma 4 31B']:
  start=time.monotonic()
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:parts=list(pool.map(lambda n:batch(model,n),range(3)))
  seen=[row['id'] for p in parts for row in p['output'] if isinstance(row,dict) and 'id' in row]
  complete=collections.Counter(seen)==collections.Counter(list(expected)) and all(p['categories_correct'] and not p['error'] and 'stop' in p['finish'] for p in parts)
  counts=dict(collections.Counter(row['category'] for p in parts for row in p['output'] if isinstance(row,dict) and 'category' in row))
  missing=[row['id'] for p in parts[:-1] for row in p['output'] if isinstance(row,dict) and 'id' in row]
  duplicates=seen+seen[:1]
  result={'model':model,'elapsed_s':time.monotonic()-start,'records':60,'batches':parts,'complete':complete,'counts':counts,'missing_batch_rejected':collections.Counter(missing)!=collections.Counter(list(expected)),'duplicate_record_rejected':collections.Counter(duplicates)!=collections.Counter(list(expected))}
  results.append(result);(root/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='batches'}),flush=True)
finally:client.close()
