"""Capture experiment evidence; exclude runtime DBs, installed dependencies and credentials."""
from pathlib import Path
import hashlib,json,subprocess,zipfile
from dotenv import dotenv_values
repo=Path.cwd();root=Path('/tmp/sage-pii-prototype');out=repo/'docs/performance';out.mkdir(exist_ok=True)
runs=[]
for p in sorted(root.glob('run-*')):
 if p.is_dir() and (p/'results.json').exists():
  runs.append({'run':p.name,'results':json.loads((p/'results.json').read_text())})
data={'kind':'synthetic_design_experiment_not_production_benchmark','sage_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'gateway_commit':'4387d1b0df5693d6dec36cf65e12a9fb5a8e67db','opencode_version':'1.18.4','runs':runs}
for key,name in [('payloads','payloads/results.json'),('invalid_flash_history','payloads-tool-history-invalid-for-flash/results.json'),('coverage','coverage/results.json'),('published_helper','gateway-probes/app-helper-results.json'),('redaction','gateway-probes/redaction-results.json'),('hooks','hook-probes/results.json'),('hook_gaps','hook-probes/direct-results.json'),('gateway_snapshot','guardrail-snapshot.json')]:
 if (root/name).exists():data[key]=json.loads((root/name).read_text())
data['source_hashes']={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [repo/'backend/sage/driver/opencode.py',repo/'backend/sage/shim/enforcement.py',repo/'backend/sage/gateway/client.py',repo/'template/react-vite/src/appLlm.ts',repo/'opencode.json']}
(out/'2026-09-14-pii-results.json').write_text(json.dumps(data,indent=2)+'\n')
files=set(p for p in root.iterdir() if p.is_file() and p.suffix in ('.py','.js','.json','.md'))
for d in ['payloads','payloads-tool-history-invalid-for-flash','coverage','gateway-probes','hook-probes']:
 for p in (root/d).rglob('*'):
  if p.is_file() and p.suffix in ('.py','.js','.mjs','.json','.md','.sse','.log') and not any(part in ('node_modules','data','config','.git') for part in p.relative_to(root/d).parts):files.add(p)
for p in root.glob('run-*'):
 if not p.is_dir():continue
 files.update(q for q in p.iterdir() if q.is_file() and q.suffix in ('.json','.log'))
 for q in p.glob('*/*'):
  if q.is_file() and q.suffix in ('.json','.jsonl','.csv','.log','.sse','.md'):files.add(q)
 files.update(q for q in p.glob('*/examples/probe/*') if q.is_file())
 log=p/'data/opencode/log/opencode.log'
 if log.exists():files.add(log)
secret=dotenv_values('/Users/subirmansukhani/Desktop/domino-sage/backend/.env')['GATEWAY_API_KEY'].encode()
manifest=[]
for p in sorted(files):
 b=p.read_bytes()
 assert secret not in b, 'Credential found; archive aborted'
 manifest.append({'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
archive=out/'2026-09-14-pii-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):z.write(p,'sage-pii-prototype/'+str(p.relative_to(root)))
 z.writestr('sage-pii-prototype/EVIDENCE-MANIFEST.json',json.dumps(manifest,indent=2))
print('Saved',len(runs),'run records;',len(manifest),'evidence files;',archive.stat().st_size,'archive bytes')
