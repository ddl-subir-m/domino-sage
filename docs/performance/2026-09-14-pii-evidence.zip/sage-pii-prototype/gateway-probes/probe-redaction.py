"""Isolate and run the gateway's actual nested redaction function; no imports/network."""
import ast
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

source_path = Path('/tmp/sage-latency-20260914/LLM_gateway/routes/gateway.py')
source_bytes = source_path.read_bytes()
source_hash = hashlib.sha256(source_bytes).hexdigest()
tree = ast.parse(source_bytes)
functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == '_redact_user_content']
assert len(functions) == 1
function = functions[0]
module = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
namespace = {'guardrail': SimpleNamespace(action='redact', modified_content='[REDACTED]')}
exec(compile(module, str(source_path), 'exec'), namespace)
redact = namespace['_redact_user_content']
fixtures = [
    ('tool_result', {'messages': [
        {'role': 'user', 'content': 'Summarize the synthetic file.'},
        {'role': 'tool', 'content': 'synthetic-tool-person@example.invalid'},
    ]}, 'synthetic-tool-person@example.invalid'),
    ('second_user_message', {'messages': [
        {'role': 'user', 'content': 'First synthetic question.'},
        {'role': 'assistant', 'content': 'Synthetic context.'},
        {'role': 'user', 'content': 'synthetic-later-person@example.invalid'},
    ]}, 'synthetic-later-person@example.invalid'),
    ('second_text_part', {'messages': [
        {'role': 'user', 'content': [
            {'type': 'text', 'text': 'First synthetic text part.'},
            {'type': 'text', 'text': 'synthetic-part-person@example.invalid'},
        ]},
    ]}, 'synthetic-part-person@example.invalid'),
]
observations = []
for name, body, marker in fixtures:
    original = json.loads(json.dumps(body))
    redact(body)
    unchanged_marker_present = marker in json.dumps(body)
    assert unchanged_marker_present
    observations.append({'name': name, 'before': original, 'after': body, 'unchangedSyntheticString': marker, 'unchangedStringStillPresent': unchanged_marker_present})
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == source_hash
result = {
    'generatedAt': datetime.now(timezone.utc).isoformat(),
    'sourcePath': str(source_path), 'sourceSha256': source_hash, 'sourceUnchanged': True,
    'sourceFunction': function.name, 'sourceStartLine': function.lineno, 'sourceEndLine': function.end_lineno,
    'method': 'AST extraction executes the existing function with a synthetic redaction result. No gateway imports or network. Assertions describe current behavior.',
    'limits': ['Function-level probe; no HTTP or deployed gateway test.', 'Assumes an input rule already returned action=redact; does not test rule matching.'],
    'verdict': 'All three synthetic strings remain in the body after redaction.',
    'observations': observations,
}
Path(__file__).with_name('redaction-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'cases': len(observations), 'assertionsPassed': True, 'verdict': result['verdict'], 'sourceUnchanged': True}, indent=2))
