import fs from 'node:fs';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
const require = createRequire(import.meta.url);
const tsPath = process.env.PROBE_TYPESCRIPT || '/tmp/sage-latency-larger/workflow-a8a4ae/build-0-after/node_modules/typescript/lib/typescript.js';
const ts = require(tsPath);
const sourcePath = process.env.PROBE_APP_HELPER || '/Users/subirmansukhani/.codex/worktrees/40c0/domino-sage/template/react-vite/src/appLlm.ts';
const outputDir = new URL('.', import.meta.url);
const source = fs.readFileSync(sourcePath, 'utf8');
const sha = (value) => crypto.createHash('sha256').update(value).digest('hex');
const configImport = 'import { appLlmConfig } from "./appLlm.config";';
assert.equal(source.split(configImport).length, 2, 'Expected exactly one config import');
const injectedConfig = 'const appLlmConfig = { alias: "synthetic-requested-model", displayName: "Synthetic Requested Model", base: "https://gateway.invalid/v1", project: "synthetic-project" };';
// Only replace the generated config import and Vite build-time environment constants.
// askModel, httpMessage, readWhole and readStream retain their existing source unchanged.
const prepared = source.replace(configImport, injectedConfig)
  .replaceAll('import.meta.env.DEV', 'false')
  .replaceAll('import.meta.env.BASE_URL', '"/"');
const transpiled = ts.transpileModule(prepared, {
  compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
  reportDiagnostics: true,
});
assert.equal(transpiled.diagnostics?.length || 0, 0);
fs.writeFileSync(new URL('app-helper-compiled.mjs', outputDir), transpiled.outputText);
const helper = await import(new URL('app-helper-compiled.mjs', outputDir));
const observations = [];
const event = (obj) => `data: ${JSON.stringify(obj)}\n\n`;
const delta = (text) => ({ choices: [{ delta: { content: text } }] });
async function run(name, responseFactory, options = {}) {
  const calls = [];
  const displayedChunks = [];
  // No request can leave the process: every fetch returns the provided local Response.
  globalThis.fetch = async (url, init) => {
    calls.push({ url, request: JSON.parse(init.body), credentials: init.credentials });
    return responseFactory();
  };
  let returned = null;
  let error = null;
  try {
    returned = await helper.askModel([{ role: 'user', content: 'Summarize synthetic text.' }], {
      ...(options.stream ? { onToken: (t) => displayedChunks.push(t) } : {}),
    });
  } catch (e) { error = { name: e.name, message: e.message }; }
  const row = { name, mockedFetchCalls: calls.length, submitted: calls[0], returned, error, displayedChunks };
  observations.push(row);
  assert.equal(calls.length, 1);
  return row;
}
const json = (body, init = {}) => new Response(JSON.stringify(body), { headers: { 'Content-Type': 'application/json', ...init.headers }, status: init.status || 200 });
const normal = await run('normal_completion', () => json({ model: 'synthetic-requested-model', choices: [{ message: { content: 'Complete synthetic answer.' } }] }));
assert.equal(normal.returned, 'Complete synthetic answer.');
const blocked = await run('http_400_guardrail', () => json({ detail: { error: { type: 'guardrail_blocked', message: 'Blocked by synthetic rule' } } }, { status: 400 }));
assert.equal(blocked.error.message, 'The model did not answer (error 400). Try again in a moment.');
const partialError = await run('partial_sse_then_error', () => new Response(event(delta('Partial synthetic answer.')) + event({ error: { message: 'Synthetic upstream failure', type: 'server_error' } }), { headers: { 'Content-Type': 'text/event-stream' } }), { stream: true });
assert.equal(partialError.returned, 'Partial synthetic answer.');
assert.equal(partialError.error, null);
const truncated = await run('truncated_sse_without_done', () => new Response(event(delta('Partial before truncation.')) + 'data: {"choices":[', { headers: { 'Content-Type': 'text/event-stream' } }), { stream: true });
assert.equal(truncated.returned, 'Partial before truncation.');
assert.equal(truncated.error, null);
const complete = await run('complete_sse', () => new Response(event(delta('Complete stream.')) + 'data: [DONE]\n\n', { headers: { 'Content-Type': 'text/event-stream' } }), { stream: true });
assert.equal(complete.returned, 'Complete stream.');
const fallback = await run('fallback_header_and_model', () => json({ model: 'synthetic-served-model', choices: [{ message: { content: 'Fallback synthetic answer.' } }] }, { headers: { 'X-LLM-Fallback-Served-By': 'synthetic-served-model', 'X-LLM-Fallback-Reason': 'timeout' } }));
assert.equal(fallback.returned, 'Fallback synthetic answer.');
assert.equal(typeof fallback.returned, 'string');
assert.equal(sha(fs.readFileSync(sourcePath)), sha(source));
const result = {
  generatedAt: new Date().toISOString(), sourcePath, sourceSha256: sha(source), sourceUnchanged: true,
  typescriptPath: tsPath, typescriptVersion: ts.version,
  method: 'Actual appLlm.ts compiled with TypeScript; only config import and Vite environment constants injected. Every fetch mocked locally. Assertions describe observed existing behavior, not desired acceptance criteria.',
  limits: ['No live gateway/browser/production execution.', 'Transpile-only; not a full TypeScript typecheck.', 'No provider receipt can be established by mock responses.', 'No proposed implementation is included.'],
  verdicts: { normalCompletion: 'returned', guardrailBody: 'discarded; generic retry message', streamError: 'ignored; partial answer returned as success', truncatedStream: 'accepted; partial answer returned as success', fallbackEvidence: 'response model and headers discarded by public helper; only answer string returned' },
  observations,
};
fs.writeFileSync(new URL('app-helper-results.json', outputDir), JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify({ cases: observations.length, assertionsPassed: true, sourceUnchanged: true, verdicts: result.verdicts }, null, 2) + '\n');
