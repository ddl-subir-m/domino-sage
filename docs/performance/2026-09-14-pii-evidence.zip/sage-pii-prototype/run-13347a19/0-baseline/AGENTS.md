Synthetic experiment. Use only files inside this workspace. No network, installs, commits, or pushes. Python is installed.
