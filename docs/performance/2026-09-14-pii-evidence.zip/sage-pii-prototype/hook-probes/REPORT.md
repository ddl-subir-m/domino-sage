# Actual OpenCode receipt hook probes

Used installed OpenCode 1.18.4 and the unchanged `/tmp/sage-pii-prototype/receipts.js` plugin. One workspace, separate sessions, one OpenCode process for the successful run. A scripted localhost OpenAI-compatible endpoint issued tools deterministically. No live LLM Gateway requests or production edits.

## Results

| Case | Stored tool result | Next model request |
|---|---|---|
| `read sales.csv` | Contains synthetic email | Receipt; email absent |
| `bash: cat sales.csv` | Contains synthetic email | Receipt; email absent |
| Source file `read code.py` | Original code | `SOURCE_CODE_MARKER` retained |
| Missing `sales.csv` path | Error state retained | Error receipt |
| `task` child running bash | Parent task result contains synthetic email returned by scripted child | Parent receipt; email absent |
| Child bash within task | Child execution observed | Child next request has receipt; email absent |
| Explicit `data_values` selecting email | Selected email | Selected email, as intended |

All six parent cases completed. Each used two main fake model requests; task also used two child requests. Local title requests returned stub text and were excluded. The successful run's first case took 15.28 seconds including startup; warm cases took 0.31–1.03 seconds. These are local fake-provider measurements, not model performance measurements.

## Direct invocation checks

The actual plugin was also called directly with three synthetic message shapes (`direct-results.json`):

- Interrupted bash error: both `state.error` and `metadata.output` lose the email.
- Synthetic user message holding a background task result: email remains. Known uncovered path.
- Tool-call input containing an email literal: email remains. Output filtering does not filter tool-call arguments.

## Evidence and limits

`results.json` records source hashes and before/after plugin hashes. `requests.json` records the exact local provider requests. Each case has its stored OpenCode transcript. The plugin was not edited during the successful run.

The first attempt stopped on a bootstrap read timeout (`startup-timeout-results.json`). The second scripted attempt mistakenly counted title requests as tool requests; its output is retained as `title-confounded-results.json` and does not establish tool behavior. The successful attempt excludes title requests before choosing scripted tool responses.

This proves that this hook can preserve actual stored tool results while changing the model-bound view. It does not prove generic source classification, complete provenance, background task handling, argument handling, other data tools, images, compaction behavior, permissions, gateway refusals, or deployed-app enforcement. The child result contains a synthetic email supplied by the scripted model to test parent handling; it is not evidence that a real child model obtained that value.

All probe processes were stopped by their scripts. No production source, issue tracker, or main experiment script was changed.
