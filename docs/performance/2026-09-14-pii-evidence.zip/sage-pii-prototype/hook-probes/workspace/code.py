def add(a, b):
    return a + b  # SOURCE_CODE_MARKER
