Local scripted probe. No external network. Follow the user task.
