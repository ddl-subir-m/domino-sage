from pathlib import Path
import hashlib,json,os,socket,subprocess,sys,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import httpx
ROOT=Path('/tmp/sage-pii-prototype/hook-probes'); WORK=ROOT/'workspace'; WORK.mkdir(exist_ok=True)
PLUGIN=Path('/tmp/sage-pii-prototype/receipts.js'); before=hashlib.sha256(PLUGIN.read_bytes()).hexdigest()
(WORK/'sales.csv').write_text('region,revenue,email\nNorth,10,synthetic-person@example.invalid\n')
(WORK/'code.py').write_text('def add(a, b):\n    return a + b  # SOURCE_CODE_MARKER\n')
(WORK/'.pii-experiment.json').write_text(json.dumps({'receipts':True,'python':sys.executable,'sources':[{'path':'sales.csv','columns':['region','revenue','email'],'rows':1}]}))
(WORK/'AGENTS.md').write_text('Local scripted probe. No external network. Follow the user task.\n')
subprocess.run(['git','init','-q'],cwd=WORK,check=True)
requests=[]; counts={}; lock=threading.Lock()
def choose(body):
 if not body.get('tools'):
  return None,'Probe title'
 text=' '.join(str(m.get('content','')) for m in body.get('messages',[]) if m.get('role')=='user')
 if 'CHILD_PROBE' in text:case='child'
 else:case=next((x for x in ['read','bash','source','task','selection','error'] if 'CASE_'+x in text),'aux')
 with lock:
  n=counts.get(case,0);counts[case]=n+1;requests.append({'case':case,'n':n,'body':body})
 if case=='aux':return None,'Probe title'
 if n>0:return None,('CHILD_RESULT synthetic-person@example.invalid' if case=='child' else 'DONE_'+case)
 calls={'read':('read',{'filePath':str(WORK/'sales.csv')}),'bash':('bash',{'command':'cat sales.csv','description':'Read synthetic local data'}),'source':('read',{'filePath':str(WORK/'code.py')}),'child':('bash',{'command':'cat sales.csv','description':'Read synthetic child data'}),'task':('task',{'subagent_type':'probe-child','description':'Child receipt test','prompt':'CHILD_PROBE Use bash to read sales.csv.'}),'selection':('data_values',{'source':'sales.csv','columns':['email'],'reason':'Explicit synthetic selection test'}),'error':('read',{'filePath':str(WORK/'missing-sales.csv')})}
 return calls[case],None
class Handler(BaseHTTPRequestHandler):
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));call,answer=choose(body)
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
  delta={'content':answer} if call is None else {'tool_calls':[{'index':0,'id':'call_'+str(time.time_ns()),'type':'function','function':{'name':call[0],'arguments':json.dumps(call[1])}}]}
  for d,f in [(delta,None),({},'stop' if call is None else 'tool_calls')]:
   event={'id':'probe','object':'chat.completion.chunk','model':'probe-model','choices':[{'index':0,'delta':d,'finish_reason':f}]}
   self.wfile.write(('data: '+json.dumps(event)+'\n\n').encode())
  self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
 def log_message(self,*a):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
cfg={'$schema':'https://opencode.ai/config.json','model':'probe/probe-model','small_model':'probe/probe-model','plugin':['file://'+str(PLUGIN)],'provider':{'probe':{'npm':'@ai-sdk/openai-compatible','name':'Local scripted probe','options':{'baseURL':f'http://127.0.0.1:{server.server_port}/v1','apiKey':'fake-local-only'},'models':{'probe-model':{'name':'Local probe','limit':{'context':200000,'output':4096}}}}},'permission':'allow','agent':{'probe':{'mode':'primary','prompt':'Follow the local test user instructions.'},'probe-child':{'mode':'subagent','prompt':'Follow the child test instructions.'}}}
(ROOT/'opencode.json').write_text(json.dumps(cfg))
config=ROOT/'config'/'opencode';config.mkdir(parents=True,exist_ok=True)
if not (config/'node_modules').exists():(config/'node_modules').symlink_to('/Users/subirmansukhani/.config/opencode/node_modules',target_is_directory=True)
env=dict(os.environ);env.update(OPENCODE_CONFIG=str(ROOT/'opencode.json'),XDG_CONFIG_HOME=str(ROOT/'config'),XDG_DATA_HOME=str(ROOT/'data'),OPENCODE_DISABLE_AUTOUPDATE='true',OPENCODE_DISABLE_MODELS_FETCH='true',OPENCODE_DISABLE_DEFAULT_PLUGINS='true')
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
binary='/Users/subirmansukhani/Desktop/domino-sage/node_modules/opencode-darwin-arm64/bin/opencode';log=(ROOT/'server.log').open('w');proc=subprocess.Popen([binary,'serve','--hostname','127.0.0.1','--port',str(port)],cwd=WORK,env=env,stdout=log,stderr=log)
base=f'http://127.0.0.1:{port}';results=[]
try:
 for _ in range(150):
  try:
   if httpx.get(base+'/global/health',timeout=1).is_success:break
  except httpx.HTTPError:pass
  time.sleep(.2)
 for case in ['read','bash','source','error','task','selection']:
  started=time.monotonic();res=httpx.post(base+'/api/session',json={'location':{'directory':str(WORK)}},timeout=100);res.raise_for_status();sid=res.json().get('data',res.json())['id']
  res=httpx.post(base+f'/session/{sid}/prompt_async',json={'agent':'probe','model':{'providerID':'probe','modelID':'probe-model'},'parts':[{'type':'text','text':'CASE_'+case+' Execute the requested probe and finish.'}]},timeout=100);res.raise_for_status()
  deadline=time.monotonic()+130;raw=[]
  while time.monotonic()<deadline:
   try:
    res=httpx.get(base+f'/session/{sid}/message',params={'directory':str(WORK)},timeout=10);res.raise_for_status();raw=res.json()
   except httpx.ReadTimeout:
    continue
   if any(p.get('text')=='DONE_'+case for m in raw for p in m.get('parts',[])):break
   time.sleep(.2)
  (ROOT/(case+'-transcript.json')).write_text(json.dumps(raw,indent=2))
  req=[r for r in requests if r['case']==case]
  nextbody=json.dumps(req[1]['body']) if len(req)>1 else ''
  results.append({'case':case,'elapsed_s':time.monotonic()-started,'requests':len(req),'ui_email':any('synthetic-person@example.invalid' in json.dumps(p.get('state',{})) for m in raw for p in m.get('parts',[]) if p.get('type')=='tool'),'next_request_email':'synthetic-person@example.invalid' in nextbody,'next_request_receipt':'local_execution_receipt' in nextbody,'next_request_source':'SOURCE_CODE_MARKER' in nextbody,'done':any(p.get('text')=='DONE_'+case for m in raw for p in m.get('parts',[]))})
  print(json.dumps(results[-1]),flush=True)
finally:
 proc.terminate()
 try:proc.wait(timeout=8)
 except subprocess.TimeoutExpired:proc.kill();proc.wait()
 server.shutdown();server.server_close();log.close()
 (ROOT/'requests.json').write_text(json.dumps(requests,indent=2))
 (ROOT/'results.json').write_text(json.dumps({'plugin_sha256_before':before,'plugin_sha256_after':hashlib.sha256(PLUGIN.read_bytes()).hexdigest(),'cases':results,'counts':counts},indent=2))
