"""EXPERIMENT ONLY. Existing OpenCode + Sage shim/client, fixed synthetic data.
Run from repo root with backend venv Python. Never prints credentials.
"""
from pathlib import Path
import argparse, csv, hashlib, json, os, socket, subprocess, sys, threading, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import httpx
from dotenv import dotenv_values
REPO=Path.cwd(); ROOT=Path('/tmp/sage-pii-prototype'); PY=sys.executable
sys.path.insert(0,str(REPO/'backend'))
from sage.driver.opencode import OpenCodeClient
from sage.gateway.client import OpenAICompatibleClient
from sage.shim.enforcement import EnforcementShim
from sage.router.model_control import ModelControl
from sage.router.models import Mode, ModelCatalog
ap=argparse.ArgumentParser();ap.add_argument('--models',nargs='+',default=['sonnet','domino/gemini-3.7-flash','Gemma 4 31B']);ap.add_argument('--task',default='sales',choices=['sales','text']);ap.add_argument('--variants',nargs='+',default=['receipts']);args=ap.parse_args()
runroot=ROOT/('run-'+uuid.uuid4().hex[:8]);runroot.mkdir(parents=True)
v=dotenv_values('/Users/subirmansukhani/Desktop/domino-sage/backend/.env')
current={};results=[]
class RecordingGateway(OpenAICompatibleClient):
 def route(self,body,labels):
  rec={'bytes':len(json.dumps(body).encode()),'model':body.get('model'),'first_s':None,'error':None,'finish':[], 'response_models':[], 'usage':None}
  content=json.dumps(body);rec['email_in_request']='@example.invalid' in content
  rec['tools_in_history']=[m.get('name') for m in body.get('messages',[]) if m.get('role')=='tool']
  n=len(current['calls']);(current['work']/f'request-{n}.json').write_text(json.dumps(body,indent=2))
  current['calls'].append(rec);start=time.monotonic();rec['task_offset_s']=start-current.get('task_started',start);data=b''
  try:
   if n>=9: raise RuntimeError('experiment call budget reached')
   for chunk in super().route(body,labels):
    if rec['first_s'] is None:rec['first_s']=time.monotonic()-start
    data+=chunk;yield chunk
  except Exception as e:
   rec['error']=type(e).__name__;raise
  finally:
   rec['total_s']=time.monotonic()-start
   (current['work']/f'response-{n}.sse').write_bytes(data)
   for line in data.splitlines():
    if not line.startswith(b'data:') or line[5:].strip()==b'[DONE]':continue
    try:ev=json.loads(line[5:])
    except ValueError:continue
    if ev.get('model') and ev['model'] not in rec['response_models']:rec['response_models'].append(ev['model'])
    if ev.get('usage'):rec['usage']=ev['usage']
    if ev.get('error'):rec['error']='error_frame'
    for ch in ev.get('choices',[]):
     if ch.get('finish_reason'):rec['finish'].append(ch['finish_reason'])
gateway=RecordingGateway(v['GATEWAY_BASE_URL'],lambda:v['GATEWAY_API_KEY'],domino_tags=True,read_timeout_s=65)
class Handler(BaseHTTPRequestHandler):
 def do_POST(self):
  body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
  if 'title generator' in str(body.get('messages',[{}])[0].get('content','')).lower() or 'LOCAL_WARMUP_ONLY' in json.dumps(body.get('messages',[])):
   # Exclude unrelated title latency and data transfers from this isolated task experiment.
   ev={'id':'title','object':'chat.completion.chunk','model':'local-title-stub','choices':[{'index':0,'delta':{'content':'Synthetic data experiment'},'finish_reason':'stop'}]}
   self.wfile.write(('data: '+json.dumps(ev)+'\n\ndata: [DONE]\n\n').encode());return
  body['model']=current['model'];body['max_tokens']=4096;body.pop('reasoning_effort',None)
  if body.get('tools'):body['tools']=[t for t in body['tools'] if t['function']['name'] not in ('webfetch','websearch')]
  try:
   for chunk in current['shim'].handle(body,project='synthetic-pii-prototype'):
    self.wfile.write(chunk);self.wfile.flush()
  except (BrokenPipeError,ConnectionResetError):pass
 def log_message(self,*args):pass
proxy=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=proxy.serve_forever,daemon=True).start()
cfg=json.loads((REPO/'opencode.json').read_text());cfg['provider']['sage-gateway']['options']['baseURL']=f'http://127.0.0.1:{proxy.server_port}/v1'
cfg['plugin']=['file:///tmp/sage-pii-prototype/receipts-final.js']
(runroot/'opencode.json').write_text(json.dumps(cfg))
sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
env=dict(os.environ);env.update(OPENCODE_CONFIG=str(runroot/'opencode.json'),OPENCODE_DISABLE_AUTOUPDATE='true',XDG_CONFIG_HOME=str(runroot/'config'),XDG_DATA_HOME=str(runroot/'data'))
env['PATH']=str(Path(PY).parent)+':'+env['PATH']
binary='/Users/subirmansukhani/.npm/_npx/9d3b2b4f702d1ce2/node_modules/opencode-darwin-arm64/bin/opencode'
log=(runroot/'server.log').open('w');proc=subprocess.Popen([binary,'serve','--port',str(port),'--hostname','127.0.0.1'],cwd=runroot,env=env,stdout=log,stderr=log)
started=time.monotonic()
try:
 for i in range(100):
  try:
   if httpx.get(f'http://127.0.0.1:{port}/global/health',timeout=1).status_code==200:break
  except httpx.HTTPError:pass
  time.sleep(.2)
 client=OpenCodeClient(f'http://127.0.0.1:{port}')
 for mi,model in enumerate(args.models):
  for variant in (args.variants if mi%2==0 else list(reversed(args.variants))):
   work=runroot/(str(mi)+'-'+variant);work.mkdir();(work/'examples/probe').mkdir(parents=True)
   subprocess.run(['git','init','-q'],cwd=work,check=True)
   (work/'AGENTS.md').write_text('Synthetic experiment. Use only files inside this workspace. No network, installs, commits, or pushes. Python is installed.\n')
   if args.task=='sales':
    filename='sales.csv'; columns=['region','revenue','email'];rows=[['North' if i%2==0 else 'South',(i+1)*10,f'person{i}@example.invalid'] for i in range(12)]
    prompt='Thread id: probe. Use sales.csv to total revenue by region. Write examples/probe/revenue.table.json with columns region and revenue. Explain which region has more revenue and state the grand total across all regions. The artifact directory already exists.'
   else:
    filename='complaints.csv';columns=['id','complaint','email'];rows=[[f'C{i}',('Delivery was late' if i%3==0 else 'Item arrived broken' if i%3==1 else 'Unexpected charge appeared'),f'person{i}@example.invalid'] for i in range(12)]
    prompt='Thread id: probe. Use complaints.csv to identify every complaint theme and the count for each theme across all 12 records. Write examples/probe/themes.table.json and summarize the themes. The artifact directory already exists.'
   with (work/filename).open('w') as f:w=csv.writer(f);w.writerow(columns);w.writerows(rows)
   sources=[{'path':filename,'columns':columns,'rows':len(rows)}]
   (work/'.pii-experiment.json').write_text(json.dumps({'receipts':variant=='receipts','python':PY,'sources':sources}))
   prompt+='\nFile structure (no row values): '+json.dumps(sources)
   if variant=='receipts':prompt+='\nData tools return local receipts. For calculations, use analyze_data to execute Python, write the result table, and return chosen columns from it in ONE tool call. Do not use bash followed by data_values for calculations. Use values already returned by analyze_data directly; never call data_values to fetch the same result again. For semantic tasks such as complaint themes, first obtain actual text and record IDs with data_values. Do not invent a keyword classifier based on assumed content; inspect the relevant text, assign each record a theme, then compute counts and write the artifact. A correct row count alone does not prove a correct classification. This is automatic and does not need user confirmation. Tool receipts do not mean the file was unreadable. Do not read the same file again merely to get around a receipt.'
   control=ModelControl(mode=Mode.IMPLEMENT);control.arm_chat('probe')
   current={'model':model,'variant':variant,'task':args.task,'candidate':'combined-explicit-contract','calls':[],'work':work}
   current['shim']=EnforcementShim(control,ModelCatalog(model,model,model,model,model,model),gateway)
   sid=client.create_session(str(work))
   warm_started=time.monotonic()
   # Initialize this v1 workspace before measuring the task, retaining cold setup separately.
   warm=httpx.get(f'http://127.0.0.1:{port}/agent',params={'directory':str(work)},timeout=120)
   warm.raise_for_status()
   current['workspace_init_s']=time.monotonic()-warm_started
   start=time.monotonic();current['task_started']=start;first_artifact=None
   client.send_prompt(sid,prompt,agent='sage-chat');seen=False;timeout=False
   while time.monotonic()-start<190:
    if first_artifact is None and list((work/'examples/probe').glob('*.table.json')):first_artifact=time.monotonic()-start
    try:running=client.is_running(sid,directory=str(work))
    except httpx.ReadTimeout:continue
    seen=seen or running
    if seen and not running:break
    time.sleep(.2)
   else:client.interrupt(sid);timeout=True
   messages=client.messages(sid);(work/'messages.json').write_text(json.dumps(messages,indent=2))
   raw=httpx.get(f'http://127.0.0.1:{port}/session/{sid}/message',params={'directory':str(work)},timeout=10)
   if raw.status_code==200:(work/'raw-messages.json').write_text(json.dumps(raw.json(),indent=2))
   artifacts=[]
   for p in (work/'examples/probe').glob('*.table.json'):
    try:artifacts.append({'file':p.name,'value':json.loads(p.read_text())})
    except ValueError:artifacts.append({'file':p.name,'error':'invalid_json'})
   correct=False
   if args.task=='sales':
    for a in artifacts:
     try:correct=correct or {r[0]:float(r[1]) for r in a['value']['rows']}=={'North':360,'South':420}
     except (KeyError,TypeError,ValueError,IndexError):pass
   else:
    for a in artifacts:
     try:correct=correct or len(a['value']['rows'])==3 and all(float(r[1])==4 for r in a['value']['rows'])
     except (KeyError,TypeError,ValueError,IndexError):pass
   result={k:v for k,v in current.items() if k not in ('shim','work')}
   result.update(work=str(work),elapsed_s=time.monotonic()-start,first_artifact_s=first_artifact,artifact_correct=correct,timeout=timeout,artifacts=artifacts,raw_ui_contains_email='@example.invalid' in raw.text if raw.status_code==200 else None)
   results.append(result);(runroot/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('calls','artifacts')})+' calls='+str(len(result['calls'])),flush=True)
finally:
 proc.terminate()
 try:proc.wait(timeout=10)
 except subprocess.TimeoutExpired:proc.kill();proc.wait()
 log.close();gateway.close();proxy.shutdown();proxy.server_close()
 (runroot/'results.json').write_text(json.dumps(results,indent=2))
 print('RESULTS '+str(runroot/'results.json'),flush=True)
