"""Synthetic request-shape comparison, not an end-to-end agent benchmark."""
from pathlib import Path
import json,sys,time,uuid
from dotenv import dotenv_values
sys.path.insert(0,str(Path.cwd()/'backend'))
from sage.gateway.client import OpenAICompatibleClient,CostLabels
root=Path('/tmp/sage-pii-prototype/payloads');root.mkdir(exist_ok=True)
v=dotenv_values('/Users/subirmansukhani/Desktop/domino-sage/backend/.env')
client=OpenAICompatibleClient(v['GATEWAY_BASE_URL'],lambda:v['GATEWAY_API_KEY'],domino_tags=True,read_timeout_s=65)
csv='region,revenue,email\n'+'\n'.join(f'{"North" if i%2==0 else "South"},{(i+1)*10},person{i}@example.invalid' for i in range(12))
texts=[{'id':f'C{i}','complaint':['Delivery was late','Item arrived broken','Unexpected charge appeared'][i%3]} for i in range(12)]
cases=[('raw_csv',csv,'Return only JSON with North, South and total revenue, as numbers. Expected keys North, South, total.'),('local_totals',json.dumps({'North':360,'South':420,'total':780}),'Explain the supplied regional totals by returning only JSON with keys North, South, total, as numbers. Preserve the supplied values.'),('selected_text',json.dumps(texts),'Read all 12 complaint texts. Return only JSON with the counts for these keys: delivery, damage, billing. Classify every record.')]
results=[];runid=uuid.uuid4().hex
try:
 for mi,model in enumerate(['sonnet','domino/gemini-3.7-flash','Gemma 4 31B']):
  for name,payload,prompt in (cases if mi%2==0 else list(reversed(cases))):
   body={'model':model,'stream':True,'max_tokens':800,'messages':[{'role':'user','content':prompt+'\nSynthetic experiment '+runid+'\nData:\n'+payload}]}
   start=time.monotonic();chunks=b'';first=None;error=None;status=None
   try:
    for chunk in client.route(body,CostLabels('ask','ask',component='probe',project_name='synthetic-pii-payloads')):
     if first is None:first=time.monotonic()-start
     chunks+=chunk
   except Exception as e:error=type(e).__name__;status=getattr(e,'status_code',getattr(e,'status',None))
   content='';usage=None;finish=[];first_text=None;response_models=[]
   for line in chunks.splitlines():
    if not line.startswith(b'data:') or line[5:].strip()==b'[DONE]':continue
    try:event=json.loads(line[5:])
    except ValueError:continue
    usage=event.get('usage') or usage
    if event.get('error'):error='error_frame'
    if event.get('model') and event['model'] not in response_models:response_models.append(event['model'])
    for choice in event.get('choices',[]):
     content+=(choice.get('delta') or {}).get('content') or ''
     if choice.get('finish_reason'):finish.append(choice['finish_reason'])
   try:
    parsed=json.loads(content.strip().removeprefix('```json').removeprefix('```').removesuffix('```').strip())
    correct=parsed==({'delivery':4,'damage':4,'billing':4} if name=='selected_text' else {'North':360,'South':420,'total':780})
   except ValueError:correct=False
   row={'model':model,'case':name,'request_bytes':len(json.dumps(body).encode()),'first_frame_s':first,'elapsed_s':time.monotonic()-start,'error':error,'status':status,'finish':finish,'response_models':response_models,'usage':usage,'correct':correct,'answer':content}
   results.append(row);(root/'results.json').write_text(json.dumps(results,indent=2));(root/f'{mi}-{name}.sse').write_bytes(chunks)
   print(json.dumps(row),flush=True)
finally:
 client.close()
